package jdbc;

import java.sql.Connection;
import java.sql.SQLException;

public class AppFahrschule {

	Connection dbConn;

	public static void main(String[] args) throws SQLException {
		AppFahrschule myApp = new AppFahrschule();
		myApp.dbConn = new PostgreSQLAccess().getConnection();
		myApp.doSomething();
	}

	public void doSomething() throws SQLException {
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Account CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Kontaktformular CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Prüfungen CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Unterrichten CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS BenutzerPrüfungen CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS BenutzerUnterrichten CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Führerscheine CASCADE");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Fahrzeuge CASCADE");
		this.createTableFahrzeuge();
		this.createTableFührerscheine();
		this.createTableAccount();
		this.createTableKontaktformular();
		this.createTablePrüfungen();
		this.createTableUnterrichten();
		this.createTableBenutzerUnterrichten();
		this.createTableBenutzerPrüfungen();
		this.insertData();
	}

	public void executeUpdateWithoutParms(String sql) throws SQLException{
		System.out.println(sql);
		this.dbConn.prepareStatement(sql).executeUpdate();
	}
	
	public void createTableFahrzeuge() throws SQLException {
		this.executeUpdateWithoutParms(
			"create table Fahrzeuge(" +
				"fahrzeugid         SERIAL        primary key," +
				"type               varchar(255)  not null,"+
				"marke              varchar(255)  not null,"+
				"modell             varchar(255)  not null,"+
				"automatik          boolean       not null,"+
				"beschreibung       varchar(255)  not null"+
			")"
		);
	}

	public void createTableFührerscheine() throws SQLException {
		this.executeUpdateWithoutParms(
			"create table Führerscheine(" +
				"führerscheinid     SERIAL primary key," +
				"klasse             varchar(255)  not null,"+
				"fahrzeug           varchar(255)  not null,"+
				"beschreibung       varchar(255)  not null"+
			")"
		);
	}
	public void createTableAccount() throws SQLException {
		this.executeUpdateWithoutParms(
			"create table Account(" +
				"userid              SERIAL primary key ," +
				"vorname       varchar(128)  not null,"+
				"nachname      varchar(128)  not null,"+
				"username      varchar(128)  not null,"+
				"email         varchar(128)  not null,"+
				"handynummer   varchar(128)  not null,"+
				"password      varchar(128)  not null,"+
				"admin         boolean       default FALSE"+
			")"
		);
	}
	public void createTableKontaktformular() throws SQLException {
		this.executeUpdateWithoutParms(
				"create table Kontaktformular(" +
						"contactid     SERIAL primary key,"+
						"vorname     varchar(128)  not null,"+
						"nachname    varchar(128)  not null,"+
						"email       varchar(128)  not null,"+
						"nachricht   varchar(255)  not null"+
					")"
		);
	}
	public void createTablePrüfungen() throws SQLException {
		this.executeUpdateWithoutParms(
				"create table Prüfungen(" +
						"prüfungid       SERIAL primary key," +
						"type      varchar(128)  not null,"+
						"name      varchar(128)  not null,"+
						"preis     varchar(128)  not null,"+
						"date      varchar(128)  not null,"+
						"beschreibung       varchar(255)  not null"+
					")"
		);
	}
	public void createTableUnterrichten() throws SQLException {
		this.executeUpdateWithoutParms(
				"create table Unterrichten(" +
						"unterrichtid     SERIAL primary key," +
						"type         varchar(128)  not null,"+
						"name         varchar(128)  not null,"+
						"date         varchar(128)  not null,"+
						"preis        int           not null,"+
						"beschreibung       varchar(255)  not null"+
					")"
		);
	}

	public void createTableBenutzerUnterrichten() throws SQLException {
		this.executeUpdateWithoutParms(
				"create table BenutzerUnterrichten(" +
						"userid         int           not null," + 
						"unterrichtid   int           not null," +
						" PRIMARY KEY (userid, unterrichtid),"+
						" FOREIGN KEY (userid) REFERENCES Account(userid) ON DELETE CASCADE,"+
						" FOREIGN KEY (unterrichtid) REFERENCES Unterrichten(unterrichtid) ON DELETE CASCADE"+
						

					")"
		);
	}
	public void createTableBenutzerPrüfungen() throws SQLException {
		this.executeUpdateWithoutParms(
				"create table BenutzerPrüfungen(" +
						"userid      int           not null," +
						"prüfungid   int           not null," +
						"bestanden   boolean               ," +
						" PRIMARY KEY (userid, prüfungid),"+
						" FOREIGN KEY (userid) REFERENCES Account(userid) ON DELETE CASCADE,"+
						" FOREIGN KEY (prüfungid) REFERENCES Prüfungen(prüfungid)ON DELETE CASCADE"+
					")"
		);
	}
	public void insertData() throws SQLException {
		this.executeUpdateWithoutParms(
			"insert into Führerscheine" +
			"(klasse, fahrzeug, beschreibung)" +
			"VALUES" +
			"('AM', 'Moped, Mokick, Leichtmofa (bis 45 km/h)', 'Kleinstkrafträder mit begrenzter Geschwindigkeit und Hubraum'),"+
			"('A1', 'Leichtkraftrad (bis 125 cm³, bis 11 kW)', 'Leichtkrafträder mit kleinem Hubraum und Leistung'),"+
			"('A2', 'Motorrad (bis 35 kW)', 'Motorräder mit mittlerer Leistung'),"+
			"('A', 'Motorrad (unbegrenzt)', 'Motorräder ohne Leistungsbeschränkung'),"+
			"('B', 'Pkw (bis 3,5 t)', 'Personenkraftwagen mit zulässiger Gesamtmasse bis 3,5 Tonnen'),"+
			"('BE', 'Pkw mit Anhänger (bis 3,5 t)', 'Pkw mit Anhänger bis 3,5 Tonnen zulässiger Gesamtmasse'),"+
			"('C1', 'Lkw (bis 7,5 t)', 'Lkw mit zulässiger Gesamtmasse bis 7,5 Tonnen'),"+
			"('C1E', 'Lkw mit Anhänger (bis 7,5 t)', 'Lkw mit Anhänger bis 7,5 Tonnen zulässiger Gesamtmasse'),"+
			"('C', 'Lkw (über 7,5 t)', 'Lkw ohne zulässige Gesamtmassebeschränkung'),"+
			"('CE', 'Lkw mit Anhänger (über 7,5 t)', 'Lkw mit Anhänger ohne zulässige Gesamtmassebeschränkung'),"+
			"('D1', 'Bus (bis 16 Sitzplätze)', 'Busse mit bis zu 16 Sitzplätzen (ausgenommen Fahrer)'),"+
			"('D1E', 'Bus mit Anhänger (bis 16 Sitzplätze)', 'Busse mit Anhänger bis zu 16 Sitzplätzen (ausgenommen Fahrer)'),"+
			"('D', 'Bus (über 16 Sitzplätze)', 'Busse ohne Sitzplatzbeschränkung'),"+
			"('DE', 'Bus mit Anhänger (über 16 Sitzplätze)', 'Busse mit Anhänger ohne Sitzplatzbeschränkung'),"+
			"('T', 'Land- und forstwirtschaftliche Zugmaschinen', 'Traktoren und andere landwirtschaftliche Fahrzeuge'),"+
			"('L', 'Zugmaschinen (bis 40 km/h)', 'Langsamfahrende Zugmaschinen')"
		);
		
		this.executeUpdateWithoutParms(
				"insert into bwi520_636107.Fahrzeuge" +
				"(type,marke,modell, automatik, beschreibung)" +
				"VALUES" +
	            "('PKW','VW', 'Golf', FALSE, 'Kompakter Wagen mit sportlichem Handling und moderner Ausstattung'),"+
	            "('PKW','Mercedes', 'C-Klasse', True, 'Elegante Limousine mit hohem Komfort und Sicherheitsniveau'),"+
	            "('PKW','Toyota', 'Yaris', FALSE, 'Praktischer Kleinwagen mit zuverlässiger Technik und geringem Verbrauch'),"+
	            "('PKW','Opel', 'Corsa', TRUE, 'Handlicher Kleinwagen mit sparsamem Motor und guter Übersicht'),"+
	            "('MRD','Yamaha', 'Tracer 7', TRUE, 'Sportlich-touringorientierter Reisemotorrad'),"+
	            "('MRD','BMW', 'G310GS', FALSE, 'Leichtes und handliches Enduro für den Einstieg')"
			);
		
		this.executeUpdateWithoutParms(
				"insert into Unterrichten" +
				"(type,name,date,preis,beschreibung)" +
				"VALUES" +
	            "('Theorie','Thema 1', '04.03.2024','0', 'Persönliche Voraussetzungen, Risikofaktor Mensch'),"+
	            "('Theorie','Thema 2', '06.03.2024','0', 'Rechtliche Rahmenbedingungen'),"+
	            "('Theorie','Thema 3', '09.03.2024','0', 'Verkehrszeichen und Verkehrseinrichtungen'),"+
	            "('Theorie','Thema 4', '11.03.2024','0', 'Straßenverkehrssystem und seine Nutzung, Bahnübergänge'),"+
	            "('Theorie','Thema 5', '13.03.2024','0', 'Vorfahrt'),"+
	            "('Theorie','Thema 6', '16.03.2024','0', 'Verkehrsregelungen'),"+
	            "('Theorie','Thema 7', '18.03.2024','0', 'Geschwindigkeit. Abstand und umweltschonende Fahrweise'),"+
	            "('Theorie','Thema 8', '20.03.2024','0', 'Andere Teilnehmer im Straßenverkehr'),"+
	            "('Theorie','Thema 9', '23.03.2024','0', 'Verkehrsverhalten bei Fahrmanövern, Verkehrsbeobachtung'),"+
	            "('Theorie','Thema 10','25.03.2024','0', 'Ruhender Verkehr'),"+
	            "('Theorie','Thema 11','27.03.2024','0', 'Verhalten in besonderen Situationen, Folgen von Verstößen gegen die Verkehrsvorschriften'),"+
	            "('Theorie','Thema 12','30.03.2024','0', 'Lebenslanges lernen'),"+
	            "('Theorie','Thema 13 (Zusatzstoff)','01.04.2024','0','Technische Bedingungen Personen- und Güterbeförderung'),"+
	            "('Theorie','Thema 14 (Zusatzstoff)','03.04.2024','0','Umweltbewusster Umgang mit Fahrzeugen, Fahren mit Solo, Kraftwagen und Zügen'),"+
	            "('Theorie','Thema 1', '06.04.2024','0', 'Persönliche Voraussetzungen, Risikofaktor Mensch'),"+
	            "('Theorie','Thema 2', '08.04.2024','0', 'Rechtliche Rahmenbedingungen'),"+
	            "('Theorie','Thema 3', '10.04.2024','0', 'Verkehrszeichen und Verkehrseinrichtungen'),"+
	            "('Theorie','Thema 4', '13.04.2024','0', 'Straßenverkehrssystem und seine Nutzung, Bahnübergänge'),"+
	            "('Theorie','Thema 5', '15.04.2024','0', 'Vorfahrt'),"+
	            "('Theorie','Thema 6', '17.04.2024','0', 'Verkehrsregelungen'),"+
	            "('Theorie','Thema 7', '20.04.2024','0', 'Geschwindigkeit. Abstand und umweltschonende Fahrweise'),"+
	            "('Theorie','Thema 8', '22.04.2024','0', 'Andere Teilnehmer im Straßenverkehr'),"+
	            "('Theorie','Thema 9', '24.04.2024','0', 'Verkehrsverhalten bei Fahrmanövern, Verkehrsbeobachtung'),"+
	            "('Theorie','Thema 10','27.04.2024','0', 'Ruhender Verkehr'),"+
	            "('Theorie','Thema 11','29.04.2024','0', 'Verhalten in besonderen Situationen, Folgen von Verstößen gegen die Verkehrsvorschriften'),"+
	            "('Theorie','Thema 12','01.05.2024','0', 'Lebenslanges lernen'),"+
	            "('Theorie','Thema 13 (Zusatzstoff)','04.05.2024','0','Technische Bedingungen Personen- und Güterbeförderung'),"+
	            "('Theorie','Thema 14 (Zusatzstoff)','06.05.2024','0','Umweltbewusster Umgang mit Fahrzeugen, Fahren mit Solo, Kraftwagen und Zügen'),"+
	            "('Praktisch','Übungsfahrt','04.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','11.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','18.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','25.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','01.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','08.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','15.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Übungsfahrt','22.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','05.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','12.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','19.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','26.03.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','02.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','09.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','16.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Überlandfahrten','23.04.2024','55', '45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','06.03.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','13.03.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','20.03.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','27.03.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','03.04.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','10.04.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','17.04.2024','55','45 Min.'),"+
	            "('Praktisch','Autobahnfahrt','24.04.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','07.03.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','14.03.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','21.03.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','28.03.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','04.04.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','11.04.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','18.04.2024','55','45 Min.'),"+
	            "('Praktisch','Nachtfahrt','25.04.2024','55','45 Min.')"
			);
		
		this.executeUpdateWithoutParms(
				"insert into Prüfungen" +
				"(type,name,preis,date,beschreibung)" +
				"VALUES" +
	            "('Fahr','Fahrprüfung', '195','15.03.2024','Treffpunkt: Fahrschule um 9.00 Uhr'),"+
	            "('Fahr','Fahrprüfung', '195','15.04.2024','Treffpunkt: Fahrschule um 9.00 Uhr'),"+
	            "('Fahr','Fahrprüfung', '195','15.05.2024','Treffpunkt: Fahrschule um 9.00 Uhr'),"+
	            "('Theorie','Theorieprüfung', '215','8.03.2024','Raum 7 in Fahrschule um 10.00 Uhr'),"+
	            "('Theorie','Theorieprüfung', '215','8.04.2024','Raum 7 in Fahrschule um 10.00 Uhr'),"+
	            "('Theorie','Theorieprüfung', '215','8.05.2024','Raum 7 in Fahrschule um 10.00 Uhr')"
			);
		
		this.executeUpdateWithoutParms(
				"insert into Account" +
				"(vorname,nachname,username,email,handynummer,password,admin)" +
				"VALUES" +
	            "('Bekir', 'Kasli','bekiruser','kaslibekir1@gmail.com','01783378765','1234',FALSE),"+
	            "('Bekir', 'Kasli','bekiradmin','kaslibekir1@gmail.com','01783378765','1234',TRUE)," +
	            "('Asli', 'Admin','asliadmin','kaslibekir1@gmail.com','01783378765','1234',TRUE),"+
	            "('Asli', 'User','asliuser','aslihan.celik@outlook.de','01783378765','1234',FALSE)"
			);
	}
}
