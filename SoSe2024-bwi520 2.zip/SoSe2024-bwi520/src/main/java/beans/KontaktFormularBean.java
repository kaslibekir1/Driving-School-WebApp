package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class KontaktFormularBean {
	
	int contactid;
	String vorname;
	String nachname;
	String email;
	public int getContactid() {
		return contactid;
	}

	public void setContactid(int contactid) {
		this.contactid = contactid;
	}
	String nachricht;
	Connection dbConn;

	public KontaktFormularBean() throws NoConnectionException {
		this.dbConn = new PostgreSQLAccess().getConnection();
		
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNachricht() {
		return nachricht;
	}

	public void setNachricht(String nachricht) {
		this.nachricht = nachricht;
	}
	
	// UI
	public void insertFormular() throws SQLException{
		String sql = "insert into kontaktformular "
							+ "(vorname,nachname,email,nachricht) "
							+ "values (?,?,?,?)";
		System.out.println(sql);

		PreparedStatement prep = this.dbConn.prepareStatement(sql);

		prep.setString(1, this.vorname);
		prep.setString(2, this.nachname);
		prep.setString(3, this.email);
		prep.setString(4, this.nachricht);
		prep.executeUpdate();
	}
	// admin view
	public String readAllFormulareFromDB() throws NoConnectionException, SQLException{
		String sql = "select * from kontaktformular";
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String alleFormulare="";
		while(dbRes.next()){
			contactid= dbRes.getInt("contactid");
			vorname = dbRes.getString("vorname");
			nachname = dbRes.getString("nachname");
			email = dbRes.getString("email");
		    nachricht = dbRes.getString("nachricht");
		    alleFormulare +="<tr> " + "<td> <input type='radio' name='radioKontakt' value="+ this.contactid +">"+ contactid+ "</td> "+ "<td>"+ vorname+ "</td> " + "<td>"+ nachname+ "</td> " + "<td>"+ email + "</td> " + "<td>"+ nachricht+ "</td> "  +"</tr>";
		}
		return alleFormulare;
	}
	
	//admin view
	public void deleteFormular() throws SQLException {

        String sql ="delete from kontaktformular where contactid =?";
        PreparedStatement prep = this.dbConn.prepareStatement(sql);
        prep.setInt(1,contactid);
        prep.executeUpdate(); 
}

}
