
package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class FahrzeugeBean{
	
    int fahrzeugid;
	String type;
	String marke;
	String modell;
	boolean automatik;
	String beschreibung;
	Connection dbConn;
	
	public FahrzeugeBean() throws NoConnectionException {
		this.dbConn = new PostgreSQLAccess().getConnection();
		
	}
	
	public String readAlleFahrzeugeFromDB() throws NoConnectionException, SQLException{
		String sql = "select  fahrzeugid,type,marke,modell,automatik,beschreibung from fahrzeuge";
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String automatik="";
		String alleFahrzeuge="";
		while(dbRes.next()){
			fahrzeugid= dbRes.getInt("fahrzeugid");
			type = dbRes.getString("type");
		    marke = dbRes.getString("marke");
		    if(dbRes.getBoolean("automatik")) {
		    	automatik="Automatik";
		    }else{
		    	automatik="Schaltgetriebe";
		    };
		    modell = dbRes.getString("modell");
		    beschreibung = dbRes.getString("beschreibung");
		    alleFahrzeuge +="<tr> " + "<td>"+ type+ "</td> " + "<td>"+ marke+ "</td> " + "<td>"+ modell + "</td> "+ "<td>"+ automatik+ "</td> "   + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleFahrzeuge;
	}
	
	public String readAlleFahrzeugeFromDBRadio() throws NoConnectionException, SQLException{
		String sql = "select  fahrzeugid,type,marke,modell,automatik,beschreibung from fahrzeuge";
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String automatik="";
		String alleFahrzeuge="";
		while(dbRes.next()){
			fahrzeugid= dbRes.getInt("fahrzeugid");
			type = dbRes.getString("type");
		    marke = dbRes.getString("marke");
		    if(dbRes.getBoolean("automatik")) {
		    	automatik="Automatik";
		    }else{
		    	automatik="Schaltgetriebe";
		    };
		    modell = dbRes.getString("modell");
		    beschreibung = dbRes.getString("beschreibung");
		    alleFahrzeuge +="<tr> " +  "<td> <input type='radio' name='radioFahrzeug' value="+this.fahrzeugid + ">"+fahrzeugid +"</td> "+ "<td>"+ type+ "</td> " + "<td>"+ marke+ "</td> " + "<td>"+ modell + "</td> "+ "<td>"+ automatik+ "</td> "   + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleFahrzeuge;
	}

public void deleteFahrzeuge() throws SQLException {

    String sql ="delete from fahrzeuge where fahrzeugid =?";
    PreparedStatement prep = this.dbConn.prepareStatement(sql);
    prep.setInt(1,fahrzeugid);
    prep.executeUpdate(); 
}
public void writeFahrzeug() throws SQLException {
	try {
		 String sql = "insert into fahrzeuge "
					+ "(type,marke,modell,automatik,beschreibung) "
					+ "values(?,?,?,?,?)";
         PreparedStatement prep = this.dbConn.prepareStatement(sql);
         prep.setString(1, this.type);
         prep.setString(2, this.marke);
         prep.setString(3, this.modell);
         prep.setBoolean(4, this.automatik);
         prep.setString(5, this.beschreibung);
         prep.executeUpdate();
		
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
	
	
	public int getFahrzeugid() {
		return fahrzeugid;
	}

	public void setFahrzeugid(int fahrzeugid) {
		this.fahrzeugid = fahrzeugid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMarke() {
		return marke;
	}

	public void setMarke(String marke) {
		this.marke = marke;
	}

	public String getModell() {
		return modell;
	}

	public void setModell(String modell) {
		this.modell = modell;
	}

	public boolean isAutomatik() {
		return automatik;
	}

	public void setAutomatik(boolean automatik) {
		this.automatik = automatik;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public Connection getDbConn() {
		return dbConn;
	}

	public void setDbConn(Connection dbConn) {
		this.dbConn = dbConn;
	}

	
	
}