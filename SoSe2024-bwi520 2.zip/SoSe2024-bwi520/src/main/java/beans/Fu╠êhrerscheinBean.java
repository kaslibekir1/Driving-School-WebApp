package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class FührerscheinBean{
	
    int führerscheinid;
	String klasse;
	String fahrzeug;
	public int getFührerscheinid() {
		return führerscheinid;
	}

	public void setFührerscheinid(int führerscheinid) {
		this.führerscheinid = führerscheinid;
	}

	public String getKlasse() {
		return klasse;
	}

	public void setKlasse(String klasse) {
		this.klasse = klasse;
	}

	public String getFahrzeug() {
		return fahrzeug;
	}

	public void setFahrzeug(String fahrzeug) {
		this.fahrzeug = fahrzeug;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public Connection getDbConn() {
		return dbConn;
	}

	public void setDbConn(Connection dbConn) {
		this.dbConn = dbConn;
	}

	String beschreibung;
	Connection dbConn;
	
	public FührerscheinBean() throws NoConnectionException {
		this.dbConn = new PostgreSQLAccess().getConnection();
		
	}
	
	public String readAlleFührerscheineFromDB() throws NoConnectionException, SQLException{
		String sql = "select  führerscheinid,klasse,fahrzeug,beschreibung from führerscheine";
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String alleFührerscheine="";
		while(dbRes.next()){
			führerscheinid= dbRes.getInt("führerscheinid");
			klasse = dbRes.getString("klasse");
		    fahrzeug = dbRes.getString("fahrzeug");
		    beschreibung = dbRes.getString("beschreibung");
		    alleFührerscheine +="<tr> " + "<td>"+ klasse+ "</td> " + "<td>"+ fahrzeug+ "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleFührerscheine;
	}
	public String readAlleFührerscheineFromDBRadio() throws NoConnectionException, SQLException{
		String sql = "select  führerscheinid,klasse,fahrzeug,beschreibung from führerscheine";
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String alleFührerscheine="";
		while(dbRes.next()){
			führerscheinid= dbRes.getInt("führerscheinid");
			klasse = dbRes.getString("klasse");
		    fahrzeug = dbRes.getString("fahrzeug");
		    beschreibung = dbRes.getString("beschreibung");
		    alleFührerscheine +="<tr> " + "<td> <input type='radio' name='radioFührerschein' value="+ this.führerscheinid +">"+ führerscheinid+ "</td> "+ "<td>"+ klasse+ "</td> " + "<td>"+ fahrzeug+ "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleFührerscheine;
	}
	
public void deleteFührerschein() throws SQLException {

    String sql ="delete from führerscheine where führerscheinid =?";
    PreparedStatement prep = this.dbConn.prepareStatement(sql);
    prep.setInt(1,führerscheinid);
    prep.executeUpdate(); 
}
}
	
	

