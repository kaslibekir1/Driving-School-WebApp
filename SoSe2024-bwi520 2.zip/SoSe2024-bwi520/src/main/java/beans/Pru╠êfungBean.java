
package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class PrüfungBean{
	
    int prüfungid;
	String type;
	String name;
	String date;
	int preis;
	String beschreibung;
	Connection dbConn;
	
	public PrüfungBean() throws NoConnectionException {
		this.dbConn = new PostgreSQLAccess().getConnection();
		
	}
	
	public String readAllePrüfungenFromDB() throws NoConnectionException, SQLException{
		String sql = "select  prüfungid,type,name,preis,date,beschreibung from prüfungen";
		System.out.println(sql);
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String allePrüfungen="";
		while(dbRes.next()){
			prüfungid= dbRes.getInt("prüfungid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    allePrüfungen +="<tr> " + "<td> <input type='radio' name='radioPrüfung' value="+ this.prüfungid +">"+ prüfungid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return allePrüfungen;
	}
	
	public String readAlleBenutzerPrüfungenFromDB(int userid) throws NoConnectionException, SQLException{
		String sql = "select  prüfungid,type,name,preis,date,beschreibung from prüfungen where prüfungid in (select prüfungid from benutzerprüfungen where userid=?)";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setInt(1,userid);
		System.out.println(sql);
		ResultSet dbRes = prep.executeQuery();
		String allePrüfungen="";
		while(dbRes.next()){
			prüfungid= dbRes.getInt("prüfungid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    allePrüfungen +="<tr> " + "<td> <input   type='radio' name='radioPrüfung' value="+ this.prüfungid +">"+ prüfungid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return allePrüfungen;
	}
	
	public String readAlleBenutzerPrüfungenFromDBMail(int userid) throws NoConnectionException, SQLException{
		String sql = "select  prüfungid,type,name,preis,date,beschreibung from prüfungen where prüfungid in (select prüfungid from benutzerprüfungen where userid=?)";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setInt(1,userid);
		System.out.println(sql);
		ResultSet dbRes = prep.executeQuery();
		String allePrüfungen="<tr>" +
                "<th>Prüfung ID</th>" +
                "<th>Name</th>" +
                "<th>Date</th>" +
                "<th>Preis</th>" +
                "<th>Beschreibung</th>" +
                "</tr>";
		while(dbRes.next()){
			prüfungid= dbRes.getInt("prüfungid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    allePrüfungen +="<tr> " + "<td>"+ prüfungid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return allePrüfungen;
	}


	public int getPrüfungid() {
		return prüfungid;
	}

	public void setPrüfungid(int prüfungid) {
		this.prüfungid = prüfungid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getPreis() {
		return preis;
	}

	public void setPreis(int preis) {
		this.preis = preis;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public Connection getDbConn() {
		return dbConn;
	}

	public void setDbConn(Connection dbConn) {
		this.dbConn = dbConn;
	}
	
	public void writeBenutzerPrüfung(int userid,int prüfungid) throws SQLException {
			String sql = "insert into benutzerprüfungen "
								+ "(userid,prüfungid) "
								+ "values(?,?)";
			PreparedStatement prep = this.dbConn.prepareStatement(sql);
			prep.setInt(1, userid);
			prep.setInt(2, prüfungid);
			prep.executeUpdate();
		
		}
	public void deleteBenutzerPrüfung() throws SQLException {

        String sql ="delete from benutzerprüfungen where prüfungid =?";
        PreparedStatement prep = this.dbConn.prepareStatement(sql);
        prep.setInt(1,prüfungid);
        prep.executeUpdate(); 
}
	public void deletePrüfung() throws SQLException {

        String sql ="delete from prüfungen where prüfungid =?";
        PreparedStatement prep = this.dbConn.prepareStatement(sql);
        prep.setInt(1,prüfungid);
        prep.executeUpdate(); 
}
	public void writePrüfung() throws SQLException {
    	try {
    		 String sql = "insert into prüfungen "
						+ "(type,name,date,preis,beschreibung) "
						+ "values(?,?,?,?,?)";
	         PreparedStatement prep = this.dbConn.prepareStatement(sql);
	         prep.setString(1, this.type);
	         prep.setString(2, this.name);
	         prep.setString(3, this.date);
	         prep.setInt(4, this.preis);
	         prep.setString(5, this.beschreibung);
	         prep.executeUpdate();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
	
}

