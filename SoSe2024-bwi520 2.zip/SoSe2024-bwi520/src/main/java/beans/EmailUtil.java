package beans;


import javax.mail.*;
import javax.mail.Transport;
import javax.mail.internet.*;
import java.util.Properties;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.activation.DataSource;

public class EmailUtil {

    public static void sendEmail(String to, String from, String subject, String body) {
    	
    // simple mail protocol
            Properties props = new Properties();
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.ssl.ciphersuites", "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256\n"
            		+ "\n"
            		+ "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384\n"
            		+ "\n"
            		+ "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256\n"
            		+ "\n"
            		+ "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384\n"
            		+ "\n"
            		+ "TLS_RSA_WITH_3DES_EDE_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_RSA_WITH_AES_128_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_RSA_WITH_AES_128_GCM_SHA256\n"
            		+ "\n"
            		+ "TLS_RSA_WITH_AES_256_CBC_SHA\n"
            		+ "\n"
            		+ "TLS_RSA_WITH_AES_256_GCM_SHA384"); 

            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com"); //  (smtp.gmail.com)
            props.put("mail.smtp.port", "587/465"); // (587 for Gmail)
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.user", "agorafahrschule@gmail.com"); // Replace with your email address
            props.put("mail.smtp.password", "wpye crtd qjud mxae"); // Replace with your email password

            // google doesnt allow us to give our gmail password to third partie applications
            Session session = Session.getInstance(props, new Authenticator() {
                  @Override
                  protected PasswordAuthentication getPasswordAuthentication() {
                     return new PasswordAuthentication("agorafahrschule@gmail.com", "wpye crtd qjud mxae");
                    
                }
            });
        	try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setContent(body, "text/html"); // Set content type as HTML for formatting

            Transport.send(message);
    		
    		
    	}catch(MessagingException e) {e.printStackTrace();}

    }
}
