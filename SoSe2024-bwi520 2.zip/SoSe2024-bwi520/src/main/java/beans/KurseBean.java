package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class KurseBean{
	
    int unterrichtid;
	String type;
	String name;
	String date;
	int preis;
	String beschreibung;
	Connection dbConn;
	
	public KurseBean() throws NoConnectionException {
		unterrichtid=0;
		type="";
		name="";
		date="";
		preis=0;
		this.dbConn = new PostgreSQLAccess().getConnection();
	}
	public int getUnterrichtid() {
		return unterrichtid;
	}


	public void setUnterrichtid(int unterrichtid) {
		this.unterrichtid = unterrichtid;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public int getPreis() {
		return preis;
	}


	public void setPreis(int preis) {
		this.preis = preis;
	}


	public String getBeschreibung() {
		return beschreibung;
	}


	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}


	public Connection getDbConn() {
		return dbConn;
	}


	public void setDbConn(Connection dbConn) {
		this.dbConn = dbConn;
	}
	public String readAllPraktischeKurseFromDB() throws NoConnectionException, SQLException{
		String sql = "select unterrichtid,name,date,preis,beschreibung from unterrichten where type = 'Praktisch'";
		System.out.println(sql);
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String  alleTheoretischeKurseHtml="" ;
		while(dbRes.next()){
			unterrichtid= dbRes.getInt("unterrichtid");
		    name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis =dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    alleTheoretischeKurseHtml +="<tr> " + "<td> <input type='radio' name='radioUnterricht' value="+ this.unterrichtid +">"+ unterrichtid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleTheoretischeKurseHtml;
	}
	
	public String readAllTheorieKurseFromDB() throws NoConnectionException, SQLException{
		String sql = "select unterrichtid,name,date,preis,beschreibung from unterrichten where type ='Theorie'";
		System.out.println(sql);
		ResultSet dbRes = dbConn.prepareStatement(sql).executeQuery();
		String allePraktischeKurseHtml="";
		while(dbRes.next()){
			unterrichtid= dbRes.getInt("unterrichtid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    allePraktischeKurseHtml +="<tr> " + "<td> <input type='radio' name='radioUnterricht' value="+ this.unterrichtid +">"+ unterrichtid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return allePraktischeKurseHtml;
	}
	
	public void writeBenutzerUnterricht(int userid,int unterrichtid) throws SQLException {
		    	try {
		    		 String sql = "insert into benutzerunterrichten "
								+ "(userid,unterrichtid) "
								+ "values(?,?)";
			         PreparedStatement prep = this.dbConn.prepareStatement(sql);
			         prep.setInt(1, userid);
			         prep.setInt(2, unterrichtid);
			         prep.executeUpdate();
		    		
		    	}catch(SQLException e) {
		    		e.printStackTrace();
		    	}
		    }
		
	public String readAlleBenutzerUnterrichtenFromDB(int userid) throws NoConnectionException, SQLException{
		String sql = "select  unterrichtid,type,name,preis,date,beschreibung from unterrichten where unterrichtid in (select unterrichtid from benutzerunterrichten where userid=?)";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setInt(1,userid);
		System.out.println(sql);
		ResultSet dbRes = prep.executeQuery();
		String alleUnterrichten="";
		while(dbRes.next()){
		    unterrichtid= dbRes.getInt("unterrichtid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    alleUnterrichten +="<tr> " + "<td> <input type='radio' name='radioUnterricht' value="+ this.unterrichtid +">"+ unterrichtid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleUnterrichten;
	}
	
	public String readAlleBenutzerUnterrichtenFromDBMail(int userid) throws NoConnectionException, SQLException{
		String sql = "select  unterrichtid,type,name,preis,date,beschreibung from unterrichten where unterrichtid in (select unterrichtid from benutzerunterrichten where userid=?)";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setInt(1,userid);
		System.out.println(sql);
		ResultSet dbRes = prep.executeQuery();
		String alleUnterrichten= "<tr>" +
                "<th>Unterricht ID</th>" +
                "<th>Name</th>" +
                "<th>Date</th>" +
                "<th>Preis</th>" +
                "<th>Beschreibung</th>" +
                "</tr>"   ;
		while(dbRes.next()){
		    unterrichtid= dbRes.getInt("unterrichtid");
			name = dbRes.getString("name");
		    date = dbRes.getString("date");
		    preis = dbRes.getInt("preis");
		    beschreibung = dbRes.getString("beschreibung");
		    alleUnterrichten +="<tr> " + "<td>"+ unterrichtid+ "</td> "+ "<td>"+ name+ "</td> " + "<td>"+ date+ "</td> " + "<td>"+ preis + "</td> " + "<td>"+ beschreibung+ "</td> "  +"</tr>";
		}
		return alleUnterrichten;
	}
 
	public void getTypeSQL() throws SQLException {

            String sql ="select type from unterrichten where unterrichtid =?";
            PreparedStatement prep = this.dbConn.prepareStatement(sql);
            prep.setInt(1,unterrichtid);
            ResultSet dbRes = prep.executeQuery(); 
            while(dbRes.next()) {
	            this.type = dbRes.getString("type");
            }
		
	}
	
	public void deleteBenutzerUnterricht() throws SQLException {

        String sql ="delete from benutzerunterrichten where unterrichtid =?";
        PreparedStatement prep = this.dbConn.prepareStatement(sql);
        prep.setInt(1,unterrichtid);
        prep.executeUpdate(); 
}
	public void deleteUnterricht() throws SQLException {

        String sql ="delete from unterrichten where unterrichtid =?";
        PreparedStatement prep = this.dbConn.prepareStatement(sql);
        prep.setInt(1,unterrichtid);
        prep.executeUpdate(); 
}
	public void writeUnterricht() throws SQLException {
    	try {
    		 String sql = "insert into unterrichten "
						+ "(type,name,date,preis,beschreibung) "
						+ "values(?,?,?,?,?)";
	         PreparedStatement prep = this.dbConn.prepareStatement(sql);
	         prep.setString(1, this.type);
	         prep.setString(2, this.name);
	         prep.setString(3, this.date);
	         prep.setInt(4, this.preis);
	         prep.setString(5, this.beschreibung);
	         prep.executeUpdate();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
	
} 


