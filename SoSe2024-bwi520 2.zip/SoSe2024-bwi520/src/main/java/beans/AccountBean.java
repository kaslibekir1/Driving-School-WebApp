package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class AccountBean {

	String vorname;
	String nachname;
	String username;
	String password;
	String handynummer;
	boolean admin;
	String email;

	Connection dbConn;

// Java Bean braucht Konstruktor ohne Parameter
	public AccountBean() throws NoConnectionException {
		super();
		this.username = "";
		this.vorname = "";
		this.nachname ="";
		this.email="";
		this.password = "";
		this.dbConn = new PostgreSQLAccess().getConnection();
	}

	public boolean checkAccountExistsBoolean() throws SQLException{
		if (!this.checkAccountExists()){
			return true;
		}else{
			return false;
		}
	}
	public boolean checkAccountExists() throws SQLException{
		String sql = "select userid from account where username = ?";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		ResultSet dbRes = prep.executeQuery();
		return dbRes.next();
	}
	
	public void getResetEmail() throws SQLException{
		String sql = "select email from account where username = ?";
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		ResultSet dbRes = prep.executeQuery();
		
		while(dbRes.next()){
		    email = dbRes.getString("email");

		}
	}

	public void insertAccount() throws SQLException{
		String sql = "insert into account "
							+ "(vorname,nachname,username,email,handynummer,password) "
							+ "values(?,?,?,?,?,?)";
	

		PreparedStatement prep = this.dbConn.prepareStatement(sql);

		prep.setString(1, this.vorname);
		prep.setString(2, this.nachname);
		prep.setString(3, this.username);
		prep.setString(4, this.email);
		prep.setString(5, this.handynummer);
		prep.setString(6, this.password);
		prep.executeUpdate();
	}

	
	public void passwordAendern(String password) throws SQLException{
		String sql = "update account set password="+password+" where username=?";					
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.executeUpdate();
	}
	
	public void addAdmin() throws SQLException{
		String sql = "update account set admin = TRUE where username=?";					
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.executeUpdate();
	}
	public void deleteAccount() throws SQLException{
		String sql = "delete from account where username=?";					
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.executeUpdate();
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHandynummer() {
		return handynummer;
	}

	public void setHandynummer(String handynummer) {
		this.handynummer = handynummer;
	}

	public boolean getAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Connection getDbConn() {
		return dbConn;
	}

	public void setDbConn(Connection dbConn) {
		this.dbConn = dbConn;
	}
}