package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.NoConnectionException;
import jdbc.PostgreSQLAccess;

public class LoginBean {

	String username;
	String password;
	boolean loggedIn;
	Connection dbConn;

	public LoginBean() throws NoConnectionException {
		this.username = "";
		this.password = "";
		this.loggedIn=false;
		this.dbConn = new PostgreSQLAccess().getConnection();
	}

	public boolean checkUseridPassword() throws SQLException{
		String sql = "select username from account where username = ? and password = ?";
		System.out.println(sql);
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.setString(2, this.password);
		return prep.executeQuery().next();
	}
	public int readUserId() throws SQLException {
		String sql = "select userid from account where username = ?";
		System.out.println(sql);
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		ResultSet dbRes = prep.executeQuery();
		  if (dbRes.next()) {
		        return dbRes.getInt("userid");
		    } else {
		    	throw new SQLException("User with username '" + this.username + "' not found.");
		    }
	}

	public boolean isAdmin() throws SQLException {
		String sql = "select admin from account where username = ? and password = ? and admin = TRUE";
		System.out.println(sql);
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.setString(2, this.password);
		return prep.executeQuery().next();
	}
	
	public void deleteAccount() throws SQLException{
		String sql = "delete from account where username=?";					
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.executeUpdate();
	}
	
	public void passwordAendern(String password) throws SQLException{
		String sql = "UPDATE account SET password = '"+ password + "' WHERE username=? ;";					
		PreparedStatement prep = this.dbConn.prepareStatement(sql);
		prep.setString(1, this.username);
		prep.executeUpdate();
	}
	
	public boolean isLoggedIn() {
		return loggedIn;
	}
	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
