package beans;

public class MessageBean {
	
	String infoMessage;
	String actionMessage;

	public MessageBean() {
		
	}
	public String getMessageHtml(){
		if(this.getActionMessage() == null) this.setActionMessage("");
		if(this.getInfoMessage()== null) this.setInfoMessage("");
		String html = "";
		
		if(!(this.getInfoMessage()=="") && !(this.getActionMessage()=="")) {
			html += "<div class='alert alert-info' role='alert'>" + this.getInfoMessage() + "</div>\n";
			html += "<div class='alert alert-secondary' role='alert'>" + this.getActionMessage() + "</div>\n";
			return html;
		}else if(!(this.getActionMessage()=="")){
			html += "<div class='alert alert-secondary' role='alert'>" + this.getActionMessage() + "</div>";
			return html;
		}else if(!(this.getInfoMessage()=="")){
			html += "<div class='alert alert-info' role='alert'>" + this.getInfoMessage() + "</div>";
			return html;
		}else {
		return html;
		
		}
		

	}
	
	
	public void setKontoWelcome(String username){
		this.infoMessage = "Willkommen "+username+" in die Fahrschule Agora";
		this.setActionMessage("");
	}
	public void setAdminWelcome(String username){
		this.infoMessage = "Willkommen "+username+" in die Fahrschule Agora";
		this.setActionMessage("");
	}
	
	public void setBuchungSuccessful(){
		this.infoMessage = "Buchung Erfolgreich";
		this.setActionMessage("Buchen Sie Weiter");
	}
	
	
	
	public void setDeleteSuccessful(){
		this.infoMessage = "Delete Erfolgreich";
		this.setActionMessage("");
	}
	public void setBuchungFailed(){
		this.infoMessage = "Buchung ist fehlgeschlagen";
		this.setActionMessage("Bitte versuchen Sie es noch einmal");
	}
	

	
	public void setDeleteFailed(){
		this.infoMessage = "Delete ist fehlgeschlagen";
		this.setActionMessage("");
	}

	
	
	
	
	public void setGeneralError(){
		this.setInfoMessage("Es ist ein Fehler aufgetreten");
		this.setActionMessage("Bitte wenden Sie sich an Ihren AdministratorIn");
	}
	
	
	
	
	
	
	
	
	

	
	public String getInfoMessage() {
		return infoMessage;
	}
	public void setInfoMessage(String infoMessage) {
		this.infoMessage = infoMessage;
	}
	public String getActionMessage() {
		return actionMessage;
	}
	public void setActionMessage(String actionMessage) {
		this.actionMessage = actionMessage;
	}
}